
package BSTWithRecur;

public class Node {
    int data;
    Node leftChild, rightChild;

    public Node(int data) {
        this.data = data;
        leftChild = rightChild = null;
    }
}
